---
title: Hackerman
layout: post
subtitle: Setting things right
background: https://cdna.artstation.com/p/assets/images/images/017/302/038/large/john-nelson-banacia-render-recolor.jpg
---

# Hacker
Alright, pure motivation. No pointing fingers, yet.
<br>Su, you can do it, you’re a tough guy.
<br>This plan needs to be multi pronged.
<br>One, you’re gonna bolster your basics. You’re gonna learn how and why everything happens, at the most basic level.
<br>And, you’re gonna venture into new pastures and learn how they work. You’re gonna conquer kingdoms.
<br>And, you’re gonna learn how to do what do you more efficiently, ad not lose focus midway.
<br>You’re gonna remember what brought you down last time, and you’re not gonna repeat it.
<br>You’re gonna decide what you wanna do, and you’re gonna decimate it. Ain’t no stopping you.
<br>Just stand by these principles, and treat them like a holy tenet. That’s all you need to do, accompanied by mindfulness and agility, courage, and most importantly positivity.

Now, let’s open the bag of grievances.
 
# Man
Now, let's address the man in the room. What's going on here? It's a complete mess. What do I want? And how do I want what I want? Do I even want anything? Well, of course yes. I want everything. Just grab it all, gloat in all the success, happiness and the feeling of completeness. It's gonna happen soon. My plans will come to fruition, all in good time.

So stupid, aren't I?

<br>My plans have always been preposterous. I want to be the king of the world, I want to be the master of all trades. I’m the quintessential monkey from Monkey see, monkey do. I want to be the most talented, creative, versatile, meticulous, go getter son of a gun that there ever was. What a fantastic plan, except that that's all it is. It’s not for nothing that everyone cannot be everything. The idealist in me always ends up muddling a clear focus on any singular thing, and I don’t end up working towards polishing one of them. It’s a half baked platter, always.

And hey, that's completely fine if it's the first time it's happened to you. Or if you're a kiddo, experiencing the bitterness of it for the first time, as your nascent fantasy bubble is burst by the pin of reality. But I'm fucking 24 years old, and this has happened one too many times, and the juvenile inside of me just doesn't let go!
<br>All the headlong machinations just lead nowhere but frivolity, dissatisfaction and frustration.

So this is what happens in my typical day:
<br>I wake up at noon, still extremely sleepy and grumpy. 
<br>I rush to office, spend about 20 mintues trying to complete some unfinished task from the day before. 
<br>It's lunch time by then, and hey, a man needs to have lunch.
<br>It’s 4 by the time I’m in the zone, and I work for a good couple of hours before it’s time to go.
<br>I go home, and start the ol’ machine up, game until late night, and binge on Youtube till early morning.
<br>Good riddance, my sanity.

This has to change, if I want to retain some semblance of life. It’s all slipping away so fast, and so quiet.
God save me.

But acknowledgement is the first step to recovery, and we got that. There's no turning back from here.